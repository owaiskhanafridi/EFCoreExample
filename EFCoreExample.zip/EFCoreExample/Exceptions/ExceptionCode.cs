﻿namespace EFCoreExample.Exceptions
{
    public enum ExceptionCode
    {
        DUPLICATE_RESOURCE_EXCEPTION,
        NEGATIVE_PRICE_EXCEPTION,
        ORDER_ITEM_NOT_FOUND,
        ORDER_NOT_FOUND,
        E_UNEXPECTED_ERROR
    }
}
